cd('3rd-party/lightspeed')
install_lightspeed
cd('../fastfit')
install_fastfit
cd('../..')
demodpmm
